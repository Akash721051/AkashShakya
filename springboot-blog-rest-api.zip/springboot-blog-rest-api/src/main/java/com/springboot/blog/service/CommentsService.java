package com.springboot.blog.service;

public interface CommentsService {

}
